const { createClient } = require('@supabase/supabase-js');

// Zapier may send field names in various formats — normalize them all
function normalizeBody(raw) {
  return {
    // Kind
    vorname:          raw.vorname           || raw.first_name         || raw.firstName         || '',
    nachname:         raw.nachname          || raw.last_name          || raw.lastName          || '',
    geburtsdatum:     raw.geburtsdatum      || raw.date_of_birth      || raw.birthday          || raw.birth_date || '',
    gruppe:           raw.gruppe            || raw.group              || raw.team              || '',
    notizen:          raw.notizen           || raw.notes              || raw.comment           || '',
    // Elternteil
    elternEmail:      raw.eltern_email      || raw.elternEmail        || raw.parent_email      || raw.email      || '',
    elternVorname:    raw.eltern_vorname    || raw.elternVorname      || raw.parent_first_name || raw.parent_vorname || '',
    elternNachname:   raw.eltern_nachname   || raw.elternNachname     || raw.parent_last_name  || raw.parent_nachname || '',
    elternTelefon:    raw.eltern_telefon    || raw.elternTelefon      || raw.parent_phone      || raw.telefon    || raw.phone || '',
  };
}

function parseBody(event) {
  const ct = (event.headers['content-type'] || '').toLowerCase();
  if (ct.includes('application/json')) {
    return JSON.parse(event.body || '{}');
  }
  if (ct.includes('application/x-www-form-urlencoded')) {
    const params = new URLSearchParams(event.body || '');
    return Object.fromEntries(params.entries());
  }
  try { return JSON.parse(event.body || '{}'); } catch { return {}; }
}

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  // ── Auth ───────────────────────────────────────────────────────────────────
  const secret = process.env.ZAPIER_SECRET;
  if (secret) {
    const provided =
      event.headers['x-zapier-secret'] ||
      event.headers['authorization']?.replace('Bearer ', '') ||
      (event.queryStringParameters || {}).secret;
    if (provided !== secret) {
      return { statusCode: 401, headers, body: JSON.stringify({ error: 'Unauthorized' }) };
    }
  }

  // ── Parse & validate ───────────────────────────────────────────────────────
  let raw;
  try {
    raw = parseBody(event);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid request body' }) };
  }

  const data = normalizeBody(raw);

  // Required: Kind-Felder
  const missingKind = ['vorname', 'nachname', 'geburtsdatum'].filter(f => !data[f]?.trim());
  if (missingKind.length > 0) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: `Missing required fields: ${missingKind.join(', ')}` }),
    };
  }

  // Required: Elternteil-E-Mail (da eltern_id NOT NULL in kinder-Tabelle)
  if (!data.elternEmail.trim()) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Missing required field: eltern_email' }),
    };
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(data.geburtsdatum)) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'geburtsdatum must be in YYYY-MM-DD format' }),
    };
  }

  // ── Supabase-Client ────────────────────────────────────────────────────────
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_SERVICE_KEY;

  if (!supabaseUrl || !supabaseKey) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server configuration error: Supabase credentials missing' }),
    };
  }

  const supabase = createClient(supabaseUrl, supabaseKey);
  const email = data.elternEmail.trim().toLowerCase();

  // ── 1. Elternteil: suchen oder neu anlegen ─────────────────────────────────
  let elternteil;

  const { data: existing, error: findError } = await supabase
    .from('eltern')
    .select('*')
    .eq('email', email)
    .maybeSingle();

  if (findError) {
    console.error('Supabase eltern lookup error:', findError);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Database error during eltern lookup', detail: findError.message }),
    };
  }

  if (existing) {
    elternteil = existing;
  } else {
    // Neuen Elternteil anlegen — dafür brauchen wir zumindest Vor- und Nachname
    if (!data.elternVorname.trim() || !data.elternNachname.trim()) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: 'Elternteil not found for this email. Provide eltern_vorname and eltern_nachname to create a new one.',
        }),
      };
    }

    const { data: created, error: createError } = await supabase
      .from('eltern')
      .insert({
        vorname:  data.elternVorname.trim(),
        nachname: data.elternNachname.trim(),
        email,
        telefon:  data.elternTelefon.trim(),
        status:   'aktiv',
      })
      .select()
      .single();

    if (createError) {
      console.error('Supabase eltern insert error:', createError);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Failed to create elternteil', detail: createError.message }),
      };
    }

    elternteil = created;
  }

  // ── 2. Kind anlegen ────────────────────────────────────────────────────────
  const gruppe = data.gruppe.trim();

  const { data: kind, error: kindError } = await supabase
    .from('kinder')
    .insert({
      vorname:      data.vorname.trim(),
      nachname:     data.nachname.trim(),
      geburtsdatum: data.geburtsdatum,
      gruppe,
      eltern_id:    elternteil.id,
      status:       gruppe ? 'aktiv' : 'neuzugang',
      notizen:      data.notizen.trim(),
    })
    .select()
    .single();

  if (kindError) {
    console.error('Supabase kinder insert error:', kindError);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Failed to create kind', detail: kindError.message }),
    };
  }

  return {
    statusCode: 201,
    headers,
    body: JSON.stringify({
      success:     true,
      elternteil:  { id: elternteil.id, email: elternteil.email, neu: !existing },
      kind:        kind,
    }),
  };
};
